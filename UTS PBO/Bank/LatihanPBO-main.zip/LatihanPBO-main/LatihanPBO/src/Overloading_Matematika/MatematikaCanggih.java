/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Overloading_Matematika;

/**
 *
 * @author hp
 */
public class MatematikaCanggih {
    
//    2 Param
    
//    double
    static void pertambahan(double a, double b){
        System.out.println(a + " + "  + b + " = " + (a+b));
    }
    
    static void pengurangan(double a, double b){
        System.out.println(a + " - "  + b + " = " + (a-b));
    }
    
    static void perkalian(double a, double b){
        System.out.println(a + " * "  + b + " = " + (a*b));
    }
    
    static void pembagian(double a, double b){
        System.out.println(a + " / "  + b + " = " + (a/b));
    }
    
//    int
    static void pertambahan(int a, int b){
        System.out.println(a + " + "  + b + " = " + (a+b));
    }
    
    static void pengurangan(int a, int b){
        System.out.println(a + " - "  + b + " = " + (a-b));
    }
    
    static void perkalian(int a, int b){
        System.out.println(a + " * "  + b + " = " + (a*b));
    }
    
    static void pembagian(int a, int b){
        System.out.println(a + " / "  + b + " = " + (a/b));
    }
    
    
//    3 param
    
//    double
    static void pertambahan(double a, double b, double c){
        System.out.println(a + " + "  + b + " + " + c + " = " + (a+b));
    }
    
    static void pengurangan(double a, double b, double c){
        System.out.println(a + " - "  + b + " - " + c + " = " + (a+b+c));
    }
    
    static void perkalian(double a, double b, double c){
        System.out.println(a + " * "  + b + " * " + c + " = " + (a*b*c));
    }
    
    static void pembagian(double a, double b, double c){
        System.out.println(a + " / "  + b + " / " + c + " = " + (a/b/c));
    }
    
    static void modulus(double a, double b, double c){
        System.out.println(a + " % "  + b + " % " + c + " = " + (a%b%c));
    }
    
//    int
    
    static void pertambahan(int a, int b, int c){
        System.out.println(a + " + "  + b + " = " + (a+b));
    }
    
    static void pengurangan(int a, int b, int c){
        System.out.println(a + " - "  + b + " = " + (a-b));
    }
    
    static void perkalian(int a, int b, int c){
        System.out.println(a + " * "  + b + " = " + (a*b));
    }
    
    static void pembagian(int a, int b, int c){
        System.out.println(a + " / "  + b + " = " + (a/b));
    }
    
     static void modulus(int a, int b, int c){
        System.out.println(a + " / "  + b + " = " + (a/b));
    }
}
