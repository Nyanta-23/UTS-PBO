/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Overloading_Matematika;

/**
 *
 * @author hp
 */
public class Matematika {
    static void pertambahan(int a, int b){
        System.out.println(a + " + "  + b + " = " + (a+b));
    }
    
    static void pengurangan(int a, int b){
        System.out.println(a + " - "  + b + " = " + (a-b));
    }
    
    static void perkalian(int a, int b){
        System.out.println(a + " * "  + b + " = " + (a*b));
    }
    
    static void pembagian(int a, int b){
        System.out.println(a + " / "  + b + " = " + (a/b));
    }
}
