/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack_Matematika;

/**
 *
 * @author hp
 */
public class MateamtikaBeraksi {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Matematika opMtk = new Matematika();
    
    opMtk.pertambahan(20, 20);
    opMtk.pengurangan(10, 5);
    opMtk.perkalian(10, 20);
    opMtk.pembagian(21,2);
    
    }
    
}
