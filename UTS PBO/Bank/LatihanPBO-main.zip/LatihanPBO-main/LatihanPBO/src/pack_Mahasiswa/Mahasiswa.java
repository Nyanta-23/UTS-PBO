/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack_Mahasiswa;

/**
 *
 * @author hp
 */
public class Mahasiswa {
    static void membaca(){
        System.out.println("Buku Komik");
    }
    
    static void nyontek(){
        System.out.println("Tugas Harian");
    }
    
    static void modifikasi(){
        System.out.println("Motor bekas");
    }
}
